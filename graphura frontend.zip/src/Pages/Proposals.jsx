import React from 'react';

const Proposals = () => {
  return (
    <div className="page">
      <h1 className="section-title">Proposals</h1>
      <div className="content-placeholder">
        <p>Still in making no Data</p>
      </div>
    </div>
  );
};

export default Proposals;