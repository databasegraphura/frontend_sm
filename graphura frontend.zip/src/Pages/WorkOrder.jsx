import React from 'react';

const WorkOrder = () => {
  return (
    <div className="page">
      <h1 className="section-title">Work Order</h1>
      <div className="content-placeholder">
        <p>Work Order page content will be implemented here.</p>
      </div>
    </div>
  );
};

export default WorkOrder;
